#ifndef _ROS_scale_truck_control_lrc_h
#define _ROS_scale_truck_control_lrc_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace scale_truck_control
{

  class lrc : public ros::Msg
  {
    public:
      typedef bool _alpha_type;
      _alpha_type alpha;
      typedef float _crc_vel_type;
      _crc_vel_type crc_vel;
      typedef float _cur_vel_type;
      _cur_vel_type cur_vel;

    lrc():
      alpha(0),
      crc_vel(0),
      cur_vel(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_alpha;
      u_alpha.real = this->alpha;
      *(outbuffer + offset + 0) = (u_alpha.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->alpha);
      union {
        float real;
        uint32_t base;
      } u_crc_vel;
      u_crc_vel.real = this->crc_vel;
      *(outbuffer + offset + 0) = (u_crc_vel.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_crc_vel.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_crc_vel.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_crc_vel.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->crc_vel);
      union {
        float real;
        uint32_t base;
      } u_cur_vel;
      u_cur_vel.real = this->cur_vel;
      *(outbuffer + offset + 0) = (u_cur_vel.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_cur_vel.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_cur_vel.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_cur_vel.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->cur_vel);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_alpha;
      u_alpha.base = 0;
      u_alpha.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->alpha = u_alpha.real;
      offset += sizeof(this->alpha);
      union {
        float real;
        uint32_t base;
      } u_crc_vel;
      u_crc_vel.base = 0;
      u_crc_vel.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_crc_vel.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_crc_vel.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_crc_vel.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->crc_vel = u_crc_vel.real;
      offset += sizeof(this->crc_vel);
      union {
        float real;
        uint32_t base;
      } u_cur_vel;
      u_cur_vel.base = 0;
      u_cur_vel.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_cur_vel.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_cur_vel.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_cur_vel.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->cur_vel = u_cur_vel.real;
      offset += sizeof(this->cur_vel);
     return offset;
    }

    const char * getType(){ return "scale_truck_control/lrc"; };
    const char * getMD5(){ return "d3ed1a268b4325bf9732e4036aa8e250"; };

  };

}
#endif
